/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.tesprojekakhir;

import java.util.*;
import java.io.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Nitro
 */
public class TesProjekAkhir {

    public interface Tampilan {

        void Display();
    }

    public abstract static class Akun {

        protected final String Username;
        protected final String Password;

        public Akun(String Username, String Password) {
            this.Username = Username;
            this.Password = Password;
        }

        public String GetUsername() {
            return Username;
        }

        public String GetPassword() {
            return Password;
        }

        public abstract void Display();
    }

    public static class Admin extends Akun {

        public Admin(String Username, String Password) {
            super(Username, Password);
        }

        @Override
        public void Display() {
            System.out.println("Anda login sebagai admin");
        }
    }

    public static class User extends Akun {

        ArrayList<Favorit> daftarFavorit;

        public User(String Username, String Password) {
            super(Username, Password);
            daftarFavorit = new ArrayList<>();
        }

        @Override
        public void Display() {
            System.out.println("Anda login sebagai User");
        }

        public void tambahkanKeFavorit(Buku buku) {
//            daftarFavorit.add(buku);
            System.out.println("Buku berhasil ditambahkan ke daftar favorit.");
        }
        public void tambahkanKeFavorit2(Buku buku) {
//            daftarFavorit.add(buku);
        }

        public void lihatDaftarFavorit() {
            System.out.println("Daftar Buku Favorit:");
            for (Favorit buku : daftarFavorit) {
                buku.Display();
                buku.GetID();
                buku.GetUsername();
                buku.GetKategori();
            }
        }

    }

    public static class Favorit {

        protected String Username;
        protected int ID_Buku;
        protected String Kategori;

        public Favorit(String Username, int ID_Buku,String Kategori) {
//            this.ID=ID;
            this.Username = Username;
            this.ID_Buku = ID_Buku;
            this.Kategori = Kategori;
        }
        public void SetID(int ID){
            this.ID_Buku=ID;
        }
        public int GetID(){
            return ID_Buku;
        }

        public void SetUsername(String Username) {
            this.Username = Username;
        }

        public String GetUsername() {
            return Username;
        }
        public void SetKategori(String Kategori) {
            this.Kategori = Kategori;
        }

        public String GetKategori() {
            return Kategori;
        }
        public void coba() {
            this.GetKategori();
//            return Kategori;
        }

        public void Display() {
//            System.out.println("ID : "+GetID());
            System.out.println("ID Buku : " + GetID());
            System.out.println("Username :" + GetUsername());
        }
    }

    public static class Buku {

        protected int ID;
        protected String Judul;
        protected int Harga;
        protected String Penulis;
        protected int Stok;

        public Buku(int ID, String Judul, String Penulis, int Harga, int Stok) {
            this.ID = ID;
            this.Judul = Judul;
            this.Penulis = Penulis;
            this.Harga = Harga;
            this.Stok = Stok;
        }

        public void SetID(int ID) {
            this.ID = ID;
        }

        public int GetID() {
            return ID;
        }

        public void SetJudul(String Judul) {
            this.Judul = Judul;
        }

        public void SetHarga(int Harga) {
            this.Harga = Harga;
        }

        public String GetJudul() {
            return Judul;
        }

        public int GetHarga() {
            return Harga;
        }

        public void SetPenulis(String Penulis) {
            this.Penulis = Penulis;
        }

        public String GetPenulis() {
            return Penulis;
        }

        public void SetStok(int Stok) {
            this.Stok = Stok;
        }

        public int GetStok() {
            return Stok;
        }

        public void Display() {
            System.out.println("ID : " + GetID());
            System.out.println("Judul Buku : " + GetJudul());
            System.out.println("Harga Buku :" + GetHarga());
            System.out.println("Nama Penulis : " + GetPenulis());
            System.out.println("Stok Barang : " + GetStok());
        }
    }

    public static class Kamus extends Buku implements Tampilan {

        private String Bahasa_Awal;
        private String Bahasa_Akhir;
//        private String Jenis;

        public Kamus(int ID, String Judul, String Penulis, int Harga, int Stok, String Bahasa_Awal, String Bahasa_Akhir) {
            super(ID, Judul, Penulis, Harga, Stok);
            this.Bahasa_Awal = Bahasa_Awal;
            this.Bahasa_Akhir = Bahasa_Akhir;
//            this.Jenis=Jenis;
        }

        public void SetBahasaAwal(String Bahasa_Awal) {
            this.Bahasa_Awal = Bahasa_Awal;
        }

        public String GetBahasaAwal() {
            return Bahasa_Awal;
        }

        public void SetBahasaAkhir(String Bahasa_Akhir) {
            this.Bahasa_Akhir = Bahasa_Akhir;
        }

        public String GetBahasaAkhir() {
            return Bahasa_Akhir;
        }
//       public void SetJenis(String Jenis){
//           this.Jenis=Jenis;
//       }
//       public String GetJenis(){
//           return Jenis;
//       }

        @Override
        public void Display() {
            super.Display();
            System.out.println("Bahasa Awal : " + GetBahasaAwal());
            System.out.println("Bahasa Hasil : " + GetBahasaAkhir());
//           System.out.println("Jenis Kamus : "+GetJenis());
        }
    }

    public static class Novel extends Buku implements Tampilan {

        private String Genre;
        private int Jumlah_Bab;

        public Novel(int ID, String Judul, String Penulis, int Harga, int Stok, String Genre, int Jumlah_Bab) {
            super(ID, Judul, Penulis, Harga, Stok);
            this.Genre = Genre;
            this.Jumlah_Bab = Jumlah_Bab;
        }

        public void SetBab(int Jumlah_Bab) {
            this.Jumlah_Bab = Jumlah_Bab;
        }

        public int GetBab() {
            return Jumlah_Bab;
        }

        public void SetGenre(String Genre) {
            this.Genre = Genre;
        }

        public String GetGenre() {
            return Genre;
        }
 
        @Override
        public void Display() {
            super.Display();
            System.out.println("Genre : " + GetGenre());
            System.out.println("Jumlah Bab : " + GetBab());
        }
    }

    public static class Pelajaran extends Buku implements Tampilan {

        private String Mata_Pelajaran;
        private String Tingkat;

        public Pelajaran(int ID, String Judul, String Penulis, int Harga, int Stok, String Mata_Pelajaran, String Tingkat) {
            super(ID, Judul, Penulis, Harga, Stok);
            this.Mata_Pelajaran = Mata_Pelajaran;
            this.Tingkat = Tingkat;
        }

        public void SetMapel(String Mata_Pelajaran) {
            this.Mata_Pelajaran = Mata_Pelajaran;
        }

        public String GetMapel() {
            return Mata_Pelajaran;
        }

        public void SetTingkat(String Tingkat) {
            this.Tingkat = Tingkat;
        }

        public String GetTingkat() {
            return Tingkat;
        }

        @Override
        public void Display() {
            super.Display();
            System.out.println("Mata Pelajaran : " + GetMapel());
            System.out.println("Tingkat : " + GetTingkat());
        }
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        ArrayList<Buku> DaftarBuku = new ArrayList<>();
        ArrayList<Akun> DaftarAkun = new ArrayList<>();
//        ArrayList<Favorit> DaftarFavorit = new ArrayList<>();

        baca(DaftarBuku, DaftarAkun);
//        masukin(DaftarBuku, DaftarAkun);
//        masukin(DaftarBuku, DaftarAkun, DaftarFavorit);
//        baca(DaftarBuku, DaftarAkun, DaftarFavorit);

        int siapa;
        String username;
        String password;
        while (true) {
            try {
                System.out.println("1.Admin");
                System.out.println("2.User");
                System.out.println("3.Exit");
                System.out.print("Ingin masuk sebagai siapa ?: ");
                siapa = input.nextInt();
                input.nextLine();
                switch (siapa) {
                    case 1:
                        System.out.print("Username : ");
                        username = input.nextLine();
                        System.out.print("Password : ");
                        password = input.nextLine();
                        if (username.equalsIgnoreCase("admin") && password.equalsIgnoreCase("admin")) {
                            boolean benar = true;
                            Admin admin = new Admin(username, password); // Mengirimkan username dan password saat membuat objek Admin
                            admin.Display();
                            while (benar) {
                                try {
                                    MenuAdmin();
                                    int pilihan = input.nextInt();
                                    input.nextLine(); // membersihkan newline
                                    switch (pilihan) {
                                        case 1:
                                            Tambah(DaftarBuku, input);
                                            break;
                                        case 2:
                                            Delete(DaftarBuku, input);
                                            break;
                                        case 3:
                                            Edit(DaftarBuku, input);
                                            break;
                                        case 4:
                                            Show(DaftarBuku, input);
                                            break;
                                        case 5:
                                            Searching(DaftarBuku, input);
                                            break;
                                        case 6:
                                            Sorting(DaftarBuku, input);
                                            break;
                                        case 7:
                                            Hitung(DaftarAkun, DaftarBuku);
                                            break;
                                        case 8:
                                            Show(DaftarBuku, input, "Kamus");
                                            break;
                                        case 9:
                                            Show(DaftarBuku, input, "Novel");
                                            break;
                                        case 10:
                                            Show(DaftarBuku, input, "Pelajaran");
                                            break;
                                        case 11:
                                            benar = false;
                                            break;
                                        default:
                                            System.out.println("Input tidak valid. Silakan masukkan pilihan yang benar.");
                                    }
                                } catch (InputMismatchException e) {
                                    System.out.println("Input tidak valid. Pastikan Anda memasukkan nomor.");
                                    input.nextLine();
                                }
                            }
                        } else {
                            System.out.println("Login Sebagai Admin Gagal");
                        }
                        break;

                    case 2:
                        boolean benar2 = true;
                        while (benar2) {
                            try {
                                tampilkanMenuLogin();
                                int pilih = input.nextInt();
                                input.nextLine();
                                switch (pilih) {
                                    case 1:
                                        register(DaftarAkun, input);
                                        break;
                                    case 2:
                                        if (login(DaftarAkun, input)) { // Memeriksa hasil login
                                            boolean betul = true;
                                            while (betul) {
                                                MenuUser();
                                                int pilihan = input.nextInt();
                                                input.nextLine();
                                                switch (pilihan) {
                                                    case 1:
                                                        Show(DaftarBuku, input);
                                                        break;
                                                    case 2:
                                                        if (loggedInUser != null) {
                                                            tambahkanBukuKeFavorit(loggedInUser, DaftarBuku, input);
//                                                            tambahkanBukuKeFavorit(loggedInUser, DaftarBuku, input, DaftarFavorit);
                                                        } else {
                                                            System.out.println("Silakan login terlebih dahulu.");
                                                        }
                                                        break;

                                                    case 3:
                                                        loggedInUser.lihatDaftarFavorit();
                                                        break;

                                                    case 4:
                                                        betul = false;
                                                        break;
                                                    default:
                                                        System.out.println("Input tidak valid. Silakan masukkan pilihan yang benar.");

                                                }
                                            }
                                        } else {
                                            // Jika login gagal, jangan lanjutkan ke loop lebih dalam
                                            benar2 = false;
                                        }
                                        break;
                                    case 3:
                                        benar2 = false;
                                        break;
                                }
                            } catch (InputMismatchException e) {
                                System.out.println("Input tidak valid. Pastikan Anda memasukkan nomor.");
                                input.nextLine();
                            }
                        }
                        break;
                    case 3:
                        masukin(DaftarBuku, DaftarAkun);
//                        masukin(DaftarBuku, DaftarAkun, DaftarFavorit);
//                        exit();
                        System.exit(0);
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("Input tidak valid. Pastikan Anda memasukkan nomor.");
                input.nextLine();
            } catch (Exception e) {
                System.out.println("Terjadi kesalahan: " + e.getMessage());
                input.nextLine(); // Membersihkan buffer
                continue;
            }
        }
    }

    static void tampilkanMenuLogin() {
        System.out.println("========== Menu Login ==========");
        System.out.println("1. Register");
        System.out.println("2. Login");
        System.out.println("3. Exit");
        System.out.print("Masukkan pilihan anda : ");
    }

    static void MenuAdmin() {
        System.out.println("========== Menu Utama ==========");
        System.out.println("1. Tambah Buku");
        System.out.println("2. Hapus Buku");
        System.out.println("3. Edit Buku");
        System.out.println("4. Show");
        System.out.println("5. Searching");
        System.out.println("6. Sorting");
        System.out.println("7. Lihat Jumlah Favorit");
        System.out.println("8. Show Kamus");
        System.out.println("9. Show Novel");
        System.out.println("10.Show Pelajaran");
        System.out.println("11. Kembali");
        System.out.print("Masukkan pilihan anda : ");
    }

    static void MenuUser() {
        System.out.println("========== Menu User ==========");
        System.out.println("1. Lihat Buku");
        System.out.println("2. Tambah Buku ke Daftar Favorit");
        System.out.println("3. Lihat Daftar Favorit");
        System.out.println("4. Kembali");
        System.out.print("Masukkan pilihan anda : ");
    }

    static void Tambah(ArrayList<Buku> DaftarBuku, Scanner input) {
        System.out.println("Pilih jenis buku yang ingin ditambahkan:");
        System.out.println("1. Kamus");
        System.out.println("2. Novel");
        System.out.println("3. Mata Pelajaran");
        System.out.print("Masukkan nomor pilihan Anda: ");
        int pilihan = input.nextInt();
        input.nextLine(); // Membersihkan buffer
boolean cekid = false ;
int IDTes = 0 ;
        switch (pilihan) {
            case 1:
                System.out.println("Tambahkan buku Kamus:");
                Kamus kamus = new Kamus(0, "", "", 0, 0, "", "");
                // Memasukkan informasi kamus
                // COPAS NNTI
                System.out.print("ID: ");
                IDTes = input.nextInt();
                for (Buku buku : DaftarBuku) {
                    if (buku instanceof Kamus && buku.GetID() == IDTes) {
                        System.out.println("ID SUDAH DIGUNAKAN");
                        cekid = true ;
                    }
                }
                if(cekid){break;}
                kamus.SetID(IDTes);
                input.nextLine();
                System.out.print("Judul: ");
                kamus.SetJudul(input.nextLine());
                System.out.print("Nama Penulis: ");
                kamus.SetPenulis(input.nextLine());
                System.out.print("Harga Buku: ");
                kamus.SetHarga(input.nextInt());
                input.nextLine();
                System.out.print("Stok Buku: ");
                kamus.SetStok(input.nextInt());
                input.nextLine();
                System.out.print("Bahasa Awal: ");
                kamus.SetBahasaAwal(input.nextLine());
                System.out.print("Terjemahan ke: ");
                kamus.SetBahasaAkhir(input.nextLine());
//                System.out.print("Jenis Kamus: ");
//                kamus.SetJenis(input.nextLine());
                DaftarBuku.add(kamus);
                break;
//                }
            case 2:
                System.out.println("Tambahkan buku Novel:");
                Novel novel = new Novel(0, "", "", 0, 0, "", 0);
                // Memasukkan informasi novel
                System.out.print("ID: ");
                IDTes = input.nextInt();
                for (Buku buku : DaftarBuku) {
                    if (buku instanceof Novel && buku.GetID() == IDTes) {
                        System.out.println("ID SUDAH DIGUNAKAN");
                        cekid = true ;
                    }
                }
                if(cekid){break;}
                novel.SetID(IDTes);
//                System.out.print("ID: ");
//                novel.SetID(input.nextInt());
                input.nextLine();
                System.out.print("Judul: ");
                novel.SetJudul(input.nextLine());
                System.out.print("Penulis: ");
                novel.SetPenulis(input.nextLine());
                System.out.print("Harga: ");
                novel.SetHarga(input.nextInt());
                input.nextLine();
                System.out.print("Stok: ");
                novel.SetStok(input.nextInt());
                input.nextLine();
                System.out.print("Genre: ");
                novel.SetGenre(input.nextLine());
                System.out.print("Jumlah Bab: ");
                novel.SetBab(input.nextInt());
                input.nextLine();
                DaftarBuku.add(novel);
                break;
            case 3:
                System.out.println("Tambahkan buku Mata Pelajaran:");
                Pelajaran pelajaran = new Pelajaran(0, "", "", 0, 0, "", "");
                // Memasukkan informasi pelajaran
                System.out.print("ID: ");
                IDTes = input.nextInt();
                for (Buku buku : DaftarBuku) {
                    if (buku instanceof Pelajaran && buku.GetID() == IDTes) {
                        System.out.println("ID SUDAH DIGUNAKAN");
                        cekid = true ;
                    }
                }
                if(cekid){break;}
                pelajaran.SetID(IDTes);
                input.nextLine();
                
//                System.out.print("ID: ");
//                pelajaran.SetID(input.nextInt());
//                input.nextLine();
                System.out.print("Judul: ");
                pelajaran.SetJudul(input.nextLine());
                System.out.print("Penulis: ");
                pelajaran.SetPenulis(input.nextLine());
                System.out.print("Harga: ");
                pelajaran.SetHarga(input.nextInt());
                input.nextLine();
                System.out.print("Stok: ");
                pelajaran.SetStok(input.nextInt());
                input.nextLine();
                System.out.print("Mata Pelajaran: ");
                pelajaran.SetMapel(input.nextLine());
                System.out.print("Tingkat: ");
                pelajaran.SetTingkat(input.nextLine());
                DaftarBuku.add(pelajaran);
                break;
            default:
                System.out.println("Pilihan tidak valid.");
        }
    }

    static void Show(ArrayList<Buku> DaftarBuku, Scanner input) {
        System.out.println("Pilih kategori buku yang ingin ditampilkan:");
        System.out.println("1. Kamus");
        System.out.println("2. Novel");
        System.out.println("3. Pelajaran");
        System.out.print("Masukkan nomor pilihan Anda: ");
        int pilihanKategori = input.nextInt();
        input.nextLine(); // Membersihkan buffer

        String kategori = "";
        switch (pilihanKategori) {
            case 1:
                kategori = "Kamus";
                break;
            case 2:
                kategori = "Novel";
                break;
            case 3:
                kategori = "Pelajaran";
                break;
            default:
                System.out.println("Pilihan kategori tidak valid.");
                return;
        }

        boolean found = false;
        System.out.println("Daftar Buku kategori " + kategori + ":");
        for (Buku buku : DaftarBuku) {
            if ((buku instanceof Kamus && kategori.equalsIgnoreCase("Kamus"))
                    || (buku instanceof Novel && kategori.equalsIgnoreCase("Novel"))
                    || (buku instanceof Pelajaran && kategori.equalsIgnoreCase("Pelajaran"))) {
                buku.Display();
                found = true;
            }
        }

        if (!found) {
            System.out.println("Kategori " + kategori + " tidak ditemukan.");
        }
    }

    static void Delete(ArrayList<Buku> DaftarBuku, Scanner input) {
        System.out.println("Pilih kategori buku yang ingin dihapus:");
        System.out.println("1. Kamus");
        System.out.println("2. Novel");
        System.out.println("3. Pelajaran");
        System.out.print("Masukkan nomor pilihan Anda: ");
        int pilihanKategori = input.nextInt();
        input.nextLine(); // Membersihkan buffer

        String kategori = "";
        switch (pilihanKategori) {
            case 1:
                kategori = "Kamus";
                break;
            case 2:
                kategori = "Novel";
                break;
            case 3:
                kategori = "Pelajaran";
                break;
            default:
                System.out.println("Pilihan kategori tidak valid.");
                return;
        }

        System.out.println("Masukkan indeks buku yang ingin dihapus: ");
        int index = input.nextInt();
        input.nextLine(); // Consume newline

        if (index >= 1 && index <= DaftarBuku.size()) {
            Buku buku = DaftarBuku.get(index - 1);
            if ((buku instanceof Kamus && kategori.equalsIgnoreCase("kamus"))
                    || (buku instanceof Novel && kategori.equalsIgnoreCase("novel"))
                    || (buku instanceof Pelajaran && kategori.equalsIgnoreCase("pelajaran"))) {
                DaftarBuku.remove(index - 1);
                System.out.println("Buku berhasil dihapus.");
            } else {
                System.out.println("Buku tidak ditemukan dalam kategori yang dimaksud.");
            }
        } else {
            System.out.println("Indeks tidak valid.");
        }
    }

    static void Edit(ArrayList<Buku> DaftarBuku, Scanner input) {
        System.out.println("Pilih jenis buku yang ingin ditambahkan:");
        System.out.println("1. Kamus");
        System.out.println("2. Novel");
        System.out.println("3. Mata Pelajaran");
        System.out.print("Masukkan nomor pilihan Anda: ");
        int pilihan = input.nextInt();
        input.nextLine(); // Membersihkan buffer

        switch (pilihan) {
            case 1:
                System.out.println("Masukkan index yang ingin diubah : ");
                int index = input.nextInt();
                input.nextLine();
                if (index >= 1 && index <= DaftarBuku.size()) {
                    Kamus kamus = new Kamus(0, "", "", 0, 0, "", "");
                    // Memasukkan informasi kamus
                    System.out.print("ID: ");
                    kamus.SetID(input.nextInt());
                    input.nextLine();
                    System.out.print("Judul: ");
                    kamus.SetJudul(input.nextLine());
                    System.out.print("Nama Penulis: ");
                    kamus.SetPenulis(input.nextLine());
                    System.out.print("Harga Buku: ");
                    kamus.SetHarga(input.nextInt());
                    input.nextLine();
                    System.out.print("Stok Buku: ");
                    kamus.SetStok(input.nextInt());
                    input.nextLine();
                    System.out.print("Bahasa Awal: ");
                    kamus.SetBahasaAwal(input.nextLine());
                    System.out.print("Terjemahan ke: ");
                    kamus.SetBahasaAkhir(input.nextLine());
//                System.out.print("Jenis Kamus: ");
//                kamus.SetJenis(input.nextLine());
                    DaftarBuku.add(kamus);
                    break;
                }
            case 2:
                System.out.println("Masukkan index yang ingin diubah : ");
                index = input.nextInt();
                input.nextLine();
                if (index >= 1 && index <= DaftarBuku.size()) {
                    Novel novel = new Novel(0, "", "", 0, 0, "", 0);
                    System.out.println("ID : ");
                    int ID_Novel = input.nextInt();
                    input.nextLine();
                    novel.SetID(ID_Novel);
                    System.out.println("Judul : ");
                    String Judul_Novel = input.nextLine();
                    novel.SetJudul(Judul_Novel);
                    System.out.println("Penulis : ");
                    String Author = input.nextLine();
                    novel.SetPenulis(Author);
                    System.out.println("Masukkan Harga : ");
                    int Price = input.nextInt();
                    input.nextLine();
                    novel.SetHarga(Price);
                    System.out.println("Stok : ");
                    int Stock = input.nextInt();
                    input.nextLine();
                    novel.SetStok(Stock);
                    System.out.println("Masukkan Genre : ");
                    String Genre = input.nextLine();
                    novel.SetGenre(Genre);
                    System.out.println("Jumlah Bab : ");
                    int Bab = input.nextInt();
                    input.nextLine();
                    novel.SetBab(Bab);
                    DaftarBuku.add(new Novel(ID_Novel, Judul_Novel, Author, Price, Stock, Genre, Bab));
                    break;
                }
            case 3:
                System.out.println("Masukkan index yang ingin diubah : ");
                index = input.nextInt();
                input.nextLine();
                if (index >= 1 && index <= DaftarBuku.size()) {
                    Pelajaran pelajaran = new Pelajaran(0, "", "", 0, 0, "", "");
                    System.out.println("ID : ");
                    int ID_Pelajaran = input.nextInt();
                    input.nextLine();
                    pelajaran.SetID(ID_Pelajaran);
                    System.out.println("Judul : ");
                    String Judul_Buku = input.nextLine();
                    pelajaran.SetJudul(Judul_Buku);
                    System.out.println("Penulis : ");
                    String penulis = input.nextLine();
                    pelajaran.SetPenulis(penulis);
                    System.out.println("Harga : ");
                    int harga = input.nextInt();
                    input.nextLine();
                    pelajaran.SetHarga(harga);
                    System.out.println("Stok : ");
                    int Stok_Buku = input.nextInt();
                    input.nextLine();
                    pelajaran.SetStok(Stok_Buku);
                    System.out.println("Mata Pelajaran : ");
                    String Mapel = input.nextLine();
                    pelajaran.SetMapel(Mapel);
                    System.out.println("Tingkat : ");
                    String Tingkat = input.nextLine();
                    pelajaran.SetTingkat(Tingkat);
                    DaftarBuku.add(new Pelajaran(ID_Pelajaran, Judul_Buku, penulis, harga, Stok_Buku, Mapel, Tingkat));
                    break;
                }
            default:
                System.out.println("Jenis buku tidak valid.");
        }
    }
    public static Statement st;
    public static ResultSet rs;
    static Connection cn = koneksi.KoneksiDatabase.BukaKoneksi();

    public static void masukin(ArrayList<Buku> DaftarBuku, ArrayList<Akun> DaftarAkun) {

        try {
            String sqlA = "DELETE FROM akun";
            st.executeUpdate(sqlA);
            String sqlF = "DELETE FROM favorit";
            st.executeUpdate(sqlF);
            String sqlK = "DELETE FROM kamus";
            st.executeUpdate(sqlK);
            String sqlN = "DELETE FROM novel";
            st.executeUpdate(sqlN);
            String sqlP = "DELETE FROM pelajaran";
            st.executeUpdate(sqlP);
        } catch (Exception e) {
        }
        try {
            for (Buku buku : DaftarBuku) {
                if (buku instanceof Kamus) {
                    String sql = "INSERT INTO kamus VALUES ('" + buku.GetID() + "','" + buku.GetJudul() + "','" + buku.GetPenulis() + "','" + buku.GetHarga() + "','" + buku.GetStok() + "','" + ((Kamus) buku).GetBahasaAwal() + "','" + ((Kamus) buku).GetBahasaAkhir() + "')";
                    st.executeUpdate(sql);
                } else if (buku instanceof Novel) {
                    String sql = "INSERT INTO novel VALUES ('" + buku.GetID() + "','" + buku.GetJudul() + "','" + buku.GetPenulis() + "','" + buku.GetHarga() + "','" + buku.GetStok() + "','" + ((Novel) buku).GetGenre() + "','" + ((Novel) buku).GetBab() + "')";
                    st.executeUpdate(sql);
                } else if (buku instanceof Pelajaran) {
                    String sql = "INSERT INTO pelajaran VALUES ('" + buku.GetID() + "','" + buku.GetJudul() + "','" + buku.GetPenulis() + "','" + buku.GetHarga() + "','" + buku.GetStok() + "','" + ((Pelajaran) buku).GetMapel() + "','" + ((Pelajaran) buku).GetTingkat() + "')";
                    st.executeUpdate(sql);
                }
            }
            for (Akun akun : DaftarAkun) {
                User user = (User) akun;
                String sql2 = "INSERT INTO akun VALUES ('" + user.GetUsername() + "','" + user.GetPassword() + "')";
//                String sql = "INSERT INTO akun VALUES ('" + akun.GetUsername() + "','" + akun.GetPassword() + "')";
                st.executeUpdate(sql2);
            }
//            for (Favorit fav : DaftarFavorit) {
//                String sql = "INSERT INTO favorit VALUES ('" + fav.GetUsername() + "','" + fav.GetID_Buku() + "')";
//                st.executeUpdate(sql);
//            }
//            for (Akun akun : DaftarAkun) {
//                User user = (User) akun;
//                for (Buku fav2 : user.daftarFavorit) {
//                    String sql3 = "INSERT INTO favorit VALUES ('" + akun.GetUsername() + "','" + fav2.GetID() + "')";
//                    st.executeUpdate(sql3);
//
//                }
//            }
// baikin di bawah
            for (Akun akun : DaftarAkun) {
                User user = (User) akun;
                String kategori = "";
//                for (Buku fav2 : user.daftarFavorit) {
//                    if (fav2 instanceof Kamus) {
//                        kategori = "Kamus";
//                    } else if (fav2 instanceof Novel) {
//                        kategori = "Novel";
//                    } else if (fav2 instanceof Pelajaran) {
//                        kategori = "Pelajaran";
//                    }
//                    String sql3 = "INSERT INTO favorit VALUES ('" + akun.GetUsername() + "','" + fav2.GetID() + "','" + kategori + "')";
//                    st.executeUpdate(sql3);
//
//                }
            }

        } catch (Exception e) {
        }

    }

    public static void baca(ArrayList<Buku> DaftarBuku, ArrayList<Akun> DaftarAkun) {
        try {
            st = cn.createStatement();
            rs = st.executeQuery("SELECT * FROM akun");

            while (rs.next()) {
                Akun u = new User(
                        rs.getString("username"),
                        rs.getString("password"));
                DaftarAkun.add(u);
            }
        } catch (Exception e) {
        }

        try {
            st = cn.createStatement();
            rs = st.executeQuery("SELECT * FROM kamus");

            while (rs.next()) {
                Kamus uK = new Kamus(
                        rs.getInt("ID"),
                        rs.getString("Judul"),
                        rs.getString("Penulis"),
                        rs.getInt("Harga"),
                        rs.getInt("Stok"),
                        rs.getString("Bahasa_Awal"),
                        rs.getString("Bahasa_Akhir")
                );
                DaftarBuku.add(uK);
            }
        } catch (Exception e) {
        }
        try {
            st = cn.createStatement();
            rs = st.executeQuery("SELECT * FROM novel");

            while (rs.next()) {
                Novel u = new Novel(
                        rs.getInt("ID"),
                        rs.getString("Judul"),
                        rs.getString("Penulis"),
                        rs.getInt("Harga"),
                        rs.getInt("Stok"),
                        rs.getString("Genre"),
                        rs.getInt("Jumlah_Bab")
                );
                DaftarBuku.add(u);
            }
        } catch (Exception e) {
        }

        try {
            st = cn.createStatement();
            rs = st.executeQuery("SELECT * FROM pelajaran");

            while (rs.next()) {
                Pelajaran uK = new Pelajaran(
                        rs.getInt("ID"),
                        rs.getString("Judul"),
                        rs.getString("Penulis"),
                        rs.getInt("Harga"),
                        rs.getInt("Stok"),
                        rs.getString("Mata_Pelajaran"),
                        rs.getString("Tingkat")
                );
                DaftarBuku.add(uK);
            }
        } catch (Exception e) {
        }
        try {
            st = cn.createStatement();
            rs = st.executeQuery("SELECT * FROM favorit");
            while (rs.next()) {
                for (Akun akun : DaftarAkun) {
                    User user = (User) akun;
                    if (rs.getString("username").equals(user.GetUsername())) {
                        for (Buku buku : DaftarBuku) {
                            if (buku.GetID() == rs.getInt("id_buku") && rs.getString("kategori").equalsIgnoreCase("Kamus") && buku instanceof Kamus) {
                                Kamus kamus1 = (Kamus) buku;
                                user.tambahkanKeFavorit2(kamus1);
                            } else if (buku.GetID() == rs.getInt("id_buku") && rs.getString("kategori").equalsIgnoreCase("Novel") && buku instanceof Novel) {
                                Novel novel1 = (Novel) buku;
                                user.tambahkanKeFavorit2(novel1);
                            } else if (buku.GetID() == rs.getInt("id_buku") && rs.getString("kategori").equalsIgnoreCase("Pelajaran") && buku instanceof Pelajaran) {
                                Pelajaran pelajaran1 = (Pelajaran) buku;
                                user.tambahkanKeFavorit2(pelajaran1);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
        }

    }

    static void Searching(ArrayList<Buku> DaftarBuku, Scanner input) {
        String Cari_Judul;
        if (DaftarBuku.isEmpty()) {
            System.out.println("Daftar Buku masih kosong.");
            return;
        }
        System.out.println("Silahkan masukkan judul buku yang ingin dicari: ");
        Cari_Judul = input.nextLine();
        boolean ditemukan = false;
        for (Buku buku : DaftarBuku) {
            if (buku.GetJudul().equalsIgnoreCase(Cari_Judul)) {
                System.out.println("Buku ditemukan:");
                buku.Display();
                ditemukan = true;
                break;
            }
        }
        if (!ditemukan) {
            System.out.println("Buku dengan judul '" + Cari_Judul + "' tidak ditemukan.");
        }
    }

    static void Sorting(ArrayList<Buku> DaftarBuku, Scanner input) {
        System.out.println("Pilih jenis sorting:");
        System.out.println("1. Sorting berdasarkan ID");
        System.out.println("2. Sorting berdasarkan Judul");
        int sortingChoice = input.nextInt();
        input.nextLine();

        switch (sortingChoice) {
            case 1 -> {
                Collections.sort(DaftarBuku, (Buku buku1, Buku buku2) -> Integer.compare(buku1.GetID(), buku2.GetID()));
                System.out.println("Sorting berdasarkan ID berhasil dilakukan.");
            }
            case 2 -> {
                Collections.sort(DaftarBuku, (Buku buku1, Buku buku2) -> buku1.GetJudul().compareToIgnoreCase(buku2.GetJudul()));
                System.out.println("Sorting berdasarkan Judul berhasil dilakukan.");
            }
            default ->
                System.out.println("Pilihan sorting tidak valid.");
        }
    }// Di bagian deklarasi kelas Anda
    static User loggedInUser = null; // Inisialisasi loggedInUser sebagai null

// Di dalam method login
    static boolean login(ArrayList<Akun> DaftarAkun, Scanner input) {
        if (DaftarAkun.isEmpty()) {
            System.out.println("Silakan register terlebih dahulu");
            return false;
        }
        System.out.print("Enter username: ");
        String username = input.nextLine();
        System.out.print("Enter password: ");
        String password = input.nextLine();

        for (Akun akun : DaftarAkun) {
            if (akun instanceof User && akun.GetUsername().equals(username) && akun.GetPassword().equals(password)) {
                loggedInUser = (User) akun; // Menyimpan pengguna yang berhasil masuk
                System.out.println("Berhasil Login sebagai User");
                return true;
            }
        }
        System.out.println("Username atau password salah");
        return false;
    }

    static void register(ArrayList<Akun> DaftarAkun, Scanner input) {
        System.out.print("Enter username: ");
        String username = input.nextLine();
        System.out.print("Enter password: ");
        String password = input.nextLine();
        for (Akun akun : DaftarAkun) {
            if (akun.GetUsername().equals(username)) {
                System.out.println("Akun Sudah Terdaftar");
                return;
            }
        }
        
        Akun newUser = new User(username, password);
        DaftarAkun.add(newUser);
        System.out.println("Registration successful!");
    }

    static void tambahkanBukuKeFavorit(User user, ArrayList<Buku> DaftarBuku, Scanner input) {
        Set<Integer> idBukuFavorit = new HashSet<>(user.daftarFavorit.size());
        for (Favorit buku : user.daftarFavorit) {
            idBukuFavorit.add(buku.GetID());
        }

        System.out.println("Pilih kategori buku:");
        System.out.println("1. Kamus");
        System.out.println("2. Novel");
        System.out.println("3. Pelajaran");

        System.out.print("Masukkan nomor kategori buku: ");
        int nomorKategori = input.nextInt();
        input.nextLine(); // Membersihkan newline

        ArrayList<Buku> bukuKategoriTerpilih = new ArrayList<>();
        switch (nomorKategori) {
            case 1:
                bukuKategoriTerpilih = filterBukuByCategory(DaftarBuku, "Kamus");
                break;
            case 2:
                bukuKategoriTerpilih = filterBukuByCategory(DaftarBuku, "Novel");
                break;
            case 3:
                bukuKategoriTerpilih = filterBukuByCategory(DaftarBuku, "Pelajaran");
                break;
            default:
                System.out.println("Nomor kategori tidak valid.");
                return;
        }

        System.out.println("Pilih buku yang ingin ditambahkan ke daftar favorit:");
        for (int i = 0; i < bukuKategoriTerpilih.size(); i++) {
            Buku buku = bukuKategoriTerpilih.get(i);
            if (!idBukuFavorit.contains(buku.GetID())) {
                System.out.println((i + 1) + ". ID: " + buku.GetID() + ", Judul: " + buku.GetJudul());
            }
        }

        System.out.print("Masukkan nomor buku: ");
        int nomorBuku = input.nextInt();
        input.nextLine(); // Membersihkan newline

        if (nomorBuku >= 1 && nomorBuku <= bukuKategoriTerpilih.size()) {
            Buku buku = bukuKategoriTerpilih.get(nomorBuku - 1);
            if (!idBukuFavorit.contains(buku.GetID())) {
                user.tambahkanKeFavorit(buku);
                System.out.println("Buku berhasil ditambahkan ke daftar favorit.");
            } else {
                System.out.println("Buku sudah ada dalam daftar favorit.");
            }
        } else {
            System.out.println("Nomor buku tidak valid.");
        }
    }
//Overloading

    static void Show(ArrayList<Buku> DaftarBuku, Scanner input, String kategori) {
        boolean found = false;
        System.out.println("Daftar Buku kategori " + kategori + ":");
        for (Buku buku : DaftarBuku) {
            if ((buku instanceof Kamus && kategori.equalsIgnoreCase("Kamus"))
                    || (buku instanceof Novel && kategori.equalsIgnoreCase("Novel"))
                    || (buku instanceof Pelajaran && kategori.equalsIgnoreCase("Pelajaran"))) {
                buku.Display();
                found = true;
            }
        }

        if (!found) {
            System.out.println("Kategori " + kategori + " tidak ditemukan.");
        }
    }

    static ArrayList<Buku> filterBukuByCategory(ArrayList<Buku> DaftarBuku, String category) {
        ArrayList<Buku> bukuKategoriTerpilih = new ArrayList<>();
        for (Buku buku : DaftarBuku) {
            if ((buku instanceof Kamus && category.equalsIgnoreCase("Kamus"))
                    || (buku instanceof Novel && category.equalsIgnoreCase("Novel"))
                    || (buku instanceof Pelajaran && category.equalsIgnoreCase("Pelajaran"))) {
                bukuKategoriTerpilih.add(buku);
            }
        }
        return bukuKategoriTerpilih;
    }

    static void Hitung(ArrayList<Akun> DaftarAkun, ArrayList<Buku> DaftarBuku) {
        Scanner input = new Scanner(System.in);

        // Pilih kategori buku terlebih dahulu
        System.out.println("Pilih kategori buku yang ingin dilihat jumlah favoritnya:");
        System.out.println("1. Kamus");
        System.out.println("2. Novel");
        System.out.println("3. Pelajaran");
        System.out.print("Masukkan nomor kategori: ");
        int pilihanKategori = input.nextInt();
        input.nextLine(); // Membersihkan newline

        String kategori = "";
        switch (pilihanKategori) {
            case 1:
                kategori = "Kamus";
                break;
            case 2:
                kategori = "Novel";
                break;
            case 3:
                kategori = "Pelajaran";
                break;
            default:
                System.out.println("Pilihan kategori tidak valid.");
                return;
        }

        // Meminta input ID buku yang ingin dilihat jumlah favoritnya
        System.out.print("Masukkan ID buku yang ingin dilihat jumlah favoritnya: ");
        int idBuku = input.nextInt();
        input.nextLine(); // Membersihkan newline

        // Mencari buku dengan ID yang sesuai dalam kategori yang dipilih
        Buku buku = null;
        for (Buku b : DaftarBuku) {
            if (b.GetID() == idBuku && b instanceof Kamus && kategori.equals("Kamus")) {
                buku = b;
                break;
            } else if (b.GetID() == idBuku && b instanceof Novel && kategori.equals("Novel")) {
                buku = b;
                break;
            } else if (b.GetID() == idBuku && b instanceof Pelajaran && kategori.equals("Pelajaran")) {
                buku = b;
                break;
            }
        }

        if (buku != null) {
            // Menghitung jumlah pengguna yang memfavoritkan buku
            int jumlahFavorit = 0;
            for (Akun akun : DaftarAkun) {
                if (akun instanceof User user) {
                    if (user.daftarFavorit.contains(buku)) {
                        jumlahFavorit++;
                    }
                }
            }

            // Menampilkan hasil
            System.out.println("Jumlah pengguna yang memfavoritkan buku dengan ID " + idBuku + " Dengan Judul " + " (" + buku.GetJudul() + ") dalam kategori " + kategori + ": " + jumlahFavorit);
        } else {
            System.out.println("Buku dengan ID " + idBuku + " tidak ditemukan dalam kategori " + kategori + ".");
        }
    }
}
