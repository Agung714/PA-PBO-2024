/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package koneksi;

import java.sql.*;
import javax.swing.JOptionPane;
import com.mycompany.tesprojekakhir.TesProjekAkhir;
public class KoneksiDatabase {
    Connection cn;
    public static Connection BukaKoneksi(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection cn = DriverManager.getConnection("jdbc:mysql://localhost/dbbuku","root","");
            return cn;
            
        } catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
    
    public static boolean CheckKamusID(int id) {
    boolean exists = false;
    try {
        Connection cn = BukaKoneksi();
        PreparedStatement ps = cn.prepareStatement("SELECT id FROM kamus WHERE id = ?");
        ps.setInt(1, id);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            exists = true;
        }
        rs.close();
        ps.close();
        cn.close();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e);
    }
    return exists;
}
    
     public static void TambahData(TesProjekAkhir.Kamus kamus) {
        try {
            Connection cn = BukaKoneksi();
            PreparedStatement ps = cn.prepareStatement("INSERT INTO kamus (id, judul, penulis, harga, stok, bahasa_awal, bahasa_akhir) VALUES (?, ?, ?, ?, ?, ?, ?)");
            ps.setInt(1, kamus.GetID());
            ps.setString(2, kamus.GetJudul());
            ps.setString(3, kamus.GetPenulis());
            ps.setInt(4, kamus.GetHarga());
            ps.setInt(5, kamus.GetStok());
            ps.setString(6, kamus.GetBahasaAwal());
            ps.setString(7, kamus.GetBahasaAkhir());
            ps.executeUpdate();
            ps.close();
            cn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public static void EditData(TesProjekAkhir.Kamus kamus) {
        try {
            Connection cn = BukaKoneksi();
            PreparedStatement ps = cn.prepareStatement("UPDATE kamus SET judul = ?, penulis = ?, harga = ?, stok = ?, bahasa_awal = ?, bahasa_akhir = ? WHERE id = ?");
            ps.setString(1, kamus.GetJudul());
            ps.setString(2, kamus.GetPenulis());
            ps.setInt(3, kamus.GetHarga());
            ps.setInt(4, kamus.GetStok());
            ps.setString(5, kamus.GetBahasaAwal());
            ps.setString(6, kamus.GetBahasaAkhir());
            ps.setInt(7, kamus.GetID());
            ps.executeUpdate();
            ps.close();
            cn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

       
     public static void HapusData(int id) {
    try (Connection cn = BukaKoneksi();
         PreparedStatement ps = cn.prepareStatement("DELETE FROM kamus WHERE id = ?")) {
        ps.setInt(1, id);
        ps.executeUpdate();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e);
    }
}
      
      public static boolean CheckNovelID(int id) {
            boolean exists = false;
            try {
                Connection cn = BukaKoneksi();
                PreparedStatement ps = cn.prepareStatement("SELECT id FROM novel WHERE id = ?");
                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    exists = true;
                }
                rs.close();
                ps.close();
                cn.close();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
            return exists;
        }

        public static void TambahNovel(TesProjekAkhir.Novel novel) {
        try {
            Connection cn = BukaKoneksi();
            PreparedStatement ps = cn.prepareStatement("INSERT INTO novel (id, judul,penulis, harga,stok, genre,jumlah_bab) VALUES (?, ?, ?, ?, ?, ?, ?)");
            ps.setInt(1, novel.GetID());
            ps.setString(2, novel.GetJudul());
            ps.setString(3, novel.GetPenulis());
            ps.setInt(4, novel.GetHarga());
            ps.setInt(5, novel.GetStok());
            ps.setString(6, novel.GetGenre());
            ps.setInt(7, novel.GetBab());
            ps.executeUpdate();
            ps.close();
            cn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public static void EditNovel(TesProjekAkhir.Novel novel) {
        try {
            Connection cn = BukaKoneksi();
            PreparedStatement ps = cn.prepareStatement("UPDATE novel SET judul = ?, penulis = ?,harga = ?, stok = ?, genre = ?, jumlah_bab = ? WHERE id = ?");
            ps.setString(1, novel.GetJudul());
            ps.setString(2, novel.GetPenulis());
            ps.setInt(3, novel.GetHarga());
            ps.setInt(4, novel.GetStok());
            ps.setString(5, novel.GetGenre());
            ps.setInt(6, novel.GetBab());
            ps.setInt(7, novel.GetID());
            ps.executeUpdate();
            ps.close();
            cn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }


    public static void HapusNovel(int id) {
    try (Connection cn = BukaKoneksi();
         PreparedStatement ps = cn.prepareStatement("DELETE FROM novel WHERE id = ?")) {
        ps.setInt(1, id);
        ps.executeUpdate();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e);
    }
}
      
       public static boolean CheckPelajaranID(int id) {
        boolean exists = false;
        try {
            Connection cn = BukaKoneksi();
            PreparedStatement ps = cn.prepareStatement("SELECT id FROM pelajaran WHERE id = ?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                exists = true;
            }
            rs.close();
            ps.close();
            cn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return exists;
    }
      
        public static void TambahPelajaran(TesProjekAkhir.Pelajaran pelajaran) {
        try {
            Connection cn = BukaKoneksi();
            PreparedStatement ps = cn.prepareStatement("INSERT INTO pelajaran (id, judul, penulis, harga, stok, mata_pelajaran,tingkat) VALUES (?, ?, ?, ?, ?, ?, ?)");
            ps.setInt(1, pelajaran.GetID());
            ps.setString(2, pelajaran.GetJudul());
            ps.setString(3, pelajaran.GetPenulis());
            ps.setInt(4, pelajaran.GetHarga());
            ps.setInt(5, pelajaran.GetStok());
            ps.setString(6, pelajaran.GetMapel());
            ps.setString(7, pelajaran.GetTingkat());
            
            ps.executeUpdate();
            ps.close();
            cn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

   public static void EditPelajaran(TesProjekAkhir.Pelajaran pelajaran) {
        try {
            Connection cn = BukaKoneksi();
            PreparedStatement ps = cn.prepareStatement("UPDATE pelajaran SET judul = ?, penulis = ?, harga = ?, stok = ?, mata_pelajaran = ?, tingkat = ? WHERE id = ?");
            ps.setString(1, pelajaran.GetJudul());
            ps.setString(2, pelajaran.GetPenulis());
            ps.setInt(3, pelajaran.GetHarga());
            ps.setInt(4, pelajaran.GetStok());
            ps.setString(5, pelajaran.GetMapel());
            ps.setString(6, pelajaran.GetTingkat());
            ps.setInt(7, pelajaran.GetID());
            ps.executeUpdate();
            ps.close();
            cn.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
       
      
public static void HapusPelajaran(int id) {
    try (Connection cn = BukaKoneksi();
         PreparedStatement ps = cn.prepareStatement("DELETE FROM pelajaran WHERE id = ?")) {
        ps.setInt(1, id);
        ps.executeUpdate();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e);
    }
}
}
