/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.tesprojekakhir;

import com.mycompany.tesprojekakhir.TesProjekAkhir.Favorit;
import static com.mycompany.tesprojekakhir.TesProjekAkhir.cn;
import static com.mycompany.tesprojekakhir.TesProjekAkhir.rs;
import static com.mycompany.tesprojekakhir.TesProjekAkhir.st;
import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class menu_login extends javax.swing.JFrame {
    private static int pilih;

        public static ArrayList<TesProjekAkhir.Buku> DaftarBuku = new ArrayList<>();
        public static ArrayList<TesProjekAkhir.Akun> DaftarAkun = new ArrayList<>();
    /**
     * Creates new form Login
     */
    public menu_login(ArrayList<TesProjekAkhir.Buku> DaftarBuku,ArrayList<TesProjekAkhir.Akun> DaftarAkun) {        
        this.DaftarBuku = DaftarBuku;
        this.DaftarAkun = DaftarAkun;

        initComponents();
    }
public static void baca(ArrayList<TesProjekAkhir.Buku> DaftarBuku, ArrayList<TesProjekAkhir.Akun> DaftarAkun) {
        try {
            st = cn.createStatement();
            rs = st.executeQuery("SELECT * FROM akun");

            while (rs.next()) {
                TesProjekAkhir.Akun u = new TesProjekAkhir.User(
                        rs.getString("username"),
                        rs.getString("password"));
                DaftarAkun.add(u);
            }
        } catch (Exception e) {
        }

        try {
            st = cn.createStatement();
            rs = st.executeQuery("SELECT * FROM kamus");

            while (rs.next()) {
                TesProjekAkhir.Kamus uK = new TesProjekAkhir.Kamus(
                        rs.getInt("ID"),
                        rs.getString("Judul"),
                        rs.getString("Penulis"),
                        rs.getInt("Harga"),
                        rs.getInt("Stok"),
                        rs.getString("Bahasa_Awal"),
                        rs.getString("Bahasa_Akhir")
                );
                DaftarBuku.add(uK);
            }
        } catch (Exception e) {
        }
        try {
            st = cn.createStatement();
            rs = st.executeQuery("SELECT * FROM novel");

            while (rs.next()) {
                TesProjekAkhir.Novel u = new TesProjekAkhir.Novel(
                        rs.getInt("ID"),
                        rs.getString("Judul"),
                        rs.getString("Penulis"),
                        rs.getInt("Harga"),
                        rs.getInt("Stok"),
                        rs.getString("Genre"),
                        rs.getInt("Jumlah_Bab")
                );
                DaftarBuku.add(u);
            }
        } catch (Exception e) {
        }

        try {
            st = cn.createStatement();
            rs = st.executeQuery("SELECT * FROM pelajaran");

            while (rs.next()) {
                TesProjekAkhir.Pelajaran uK = new TesProjekAkhir.Pelajaran(
                        rs.getInt("ID"),
                        rs.getString("Judul"),
                        rs.getString("Penulis"),
                        rs.getInt("Harga"),
                        rs.getInt("Stok"),
                        rs.getString("Mata_Pelajaran"),
                        rs.getString("Tingkat")
                );
                DaftarBuku.add(uK);
            }
        } catch (Exception e) {
        }
        try {
            st = cn.createStatement();
            rs = st.executeQuery("SELECT * FROM favorit");
            while (rs.next()) {
                for (TesProjekAkhir.Akun akun : DaftarAkun) {
                    TesProjekAkhir.User user = (TesProjekAkhir.User) akun;
                    if (rs.getString("username").equals(user.GetUsername())) {
                        Favorit fav1 = new Favorit(rs.getString("username"),rs.getInt("id_buku"),rs.getString("kategori"));
                        user.daftarFavorit.add(fav1);
//                        for (TesProjekAkhir.Buku buku : DaftarBuku) {
//                            if (buku.GetID() == rs.getInt("id_buku") && rs.getString("kategori").equalsIgnoreCase("Kamus") && buku instanceof TesProjekAkhir.Kamus) {
//                                TesProjekAkhir.Kamus kamus1 = (TesProjekAkhir.Kamus) buku;
//                                user.tambahkanKeFavorit2(kamus1);
//                            } else if (buku.GetID() == rs.getInt("id_buku") && rs.getString("kategori").equalsIgnoreCase("Novel") && buku instanceof TesProjekAkhir.Novel) {
//                                TesProjekAkhir.Novel novel1 = (TesProjekAkhir.Novel) buku;
//                                user.tambahkanKeFavorit2(novel1);
//                            } else if (buku.GetID() == rs.getInt("id_buku") && rs.getString("kategori").equalsIgnoreCase("Pelajaran") && buku instanceof TesProjekAkhir.Pelajaran) {
//                                TesProjekAkhir.Pelajaran pelajaran1 = (TesProjekAkhir.Pelajaran) buku;
//                                user.tambahkanKeFavorit2(pelajaran1);
//                            }
//                        }
                    }
                }
            }
        } catch (Exception e) {
        }

    }
public static void masukin(ArrayList<TesProjekAkhir.Buku> DaftarBuku, ArrayList<TesProjekAkhir.Akun> DaftarAkun) {

        try {
            String sqlA = "DELETE FROM akun";
            st.executeUpdate(sqlA);
            String sqlF = "DELETE FROM favorit";
            st.executeUpdate(sqlF);
//            String sqlK = "DELETE FROM kamus";
//            st.executeUpdate(sqlK);
//            String sqlN = "DELETE FROM novel";
//            st.executeUpdate(sqlN);
//            String sqlP = "DELETE FROM pelajaran";
//            st.executeUpdate(sqlP);
        } catch (Exception e) {
        }
        try {
//            for (TesProjekAkhir.Buku buku : DaftarBuku) {
//                if (buku instanceof TesProjekAkhir.Kamus) {
//                    String sql = "INSERT INTO kamus VALUES ('" + buku.GetID() + "','" + buku.GetJudul() + "','" + buku.GetPenulis() + "','" + buku.GetHarga() + "','" + buku.GetStok() + "','" + ((TesProjekAkhir.Kamus) buku).GetBahasaAwal() + "','" + ((TesProjekAkhir.Kamus) buku).GetBahasaAkhir() + "')";
//                    st.executeUpdate(sql);
//                } else if (buku instanceof TesProjekAkhir.Novel) {
//                    String sql = "INSERT INTO novel VALUES ('" + buku.GetID() + "','" + buku.GetJudul() + "','" + buku.GetPenulis() + "','" + buku.GetHarga() + "','" + buku.GetStok() + "','" + ((TesProjekAkhir.Novel) buku).GetGenre() + "','" + ((TesProjekAkhir.Novel) buku).GetBab() + "')";
//                    st.executeUpdate(sql);
//                } else if (buku instanceof TesProjekAkhir.Pelajaran) {
//                    String sql = "INSERT INTO pelajaran VALUES ('" + buku.GetID() + "','" + buku.GetJudul() + "','" + buku.GetPenulis() + "','" + buku.GetHarga() + "','" + buku.GetStok() + "','" + ((TesProjekAkhir.Pelajaran) buku).GetMapel() + "','" + ((TesProjekAkhir.Pelajaran) buku).GetTingkat() + "')";
//                    st.executeUpdate(sql);
//                }
//            }
            for (TesProjekAkhir.Akun akun : DaftarAkun) {
                TesProjekAkhir.User user = (TesProjekAkhir.User) akun;
                String sql2 = "INSERT INTO akun VALUES ('" + user.GetUsername() + "','" + user.GetPassword() + "')";
//                String sql = "INSERT INTO akun VALUES ('" + akun.GetUsername() + "','" + akun.GetPassword() + "')";
                st.executeUpdate(sql2);
            }

            for (TesProjekAkhir.Akun akun : DaftarAkun) {
                TesProjekAkhir.User user = (TesProjekAkhir.User) akun;
                String kategori = "";
                for (TesProjekAkhir.Favorit fav2 : user.daftarFavorit) {
                    String sql3 = "INSERT INTO favorit VALUES ('" + akun.GetUsername() + "','" + fav2.GetID() + "','" + fav2.GetKategori() + "')";
                    st.executeUpdate(sql3);

                }
            }

        } catch (Exception e) {
        }

    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        btn_user = new javax.swing.JButton();
        btn_admin = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        btn_regis = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(136, 97, 251));
        jPanel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(136, 97, 251));
        jPanel3.setBorder(javax.swing.BorderFactory.createMatteBorder(10, 10, 10, 10, new java.awt.Color(51, 255, 204)));

        btn_user.setBackground(new java.awt.Color(51, 255, 204));
        btn_user.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_user.setForeground(new java.awt.Color(255, 255, 255));
        btn_user.setText("LOGIN USER");
        btn_user.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_userActionPerformed(evt);
            }
        });

        btn_admin.setBackground(new java.awt.Color(255, 212, 0));
        btn_admin.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_admin.setForeground(new java.awt.Color(255, 255, 255));
        btn_admin.setText("LOGIN ADMIN");
        btn_admin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_adminActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 30)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("SKY BOOK");

        jButton2.setBackground(new java.awt.Color(253, 133, 209));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("EXIT");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jSeparator2.setBackground(new java.awt.Color(255, 255, 255));
        jSeparator2.setForeground(new java.awt.Color(255, 255, 255));

        jSeparator3.setBackground(new java.awt.Color(255, 255, 255));
        jSeparator3.setForeground(new java.awt.Color(255, 255, 255));

        btn_regis.setBackground(new java.awt.Color(51, 255, 204));
        btn_regis.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_regis.setForeground(new java.awt.Color(255, 255, 255));
        btn_regis.setText("REGISTER");
        btn_regis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_regisActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_user, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_admin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_regis, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.DEFAULT_SIZE, 122, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(0, 46, Short.MAX_VALUE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(72, 72, 72)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_admin, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addComponent(btn_regis, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_user, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12))
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 450, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 490, 330));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
            masukin(DaftarBuku, DaftarAkun);
        System.exit(0);    // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void btn_adminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_adminActionPerformed
        //new login_form(1).setVisible(true);
        new Login(1,DaftarBuku, DaftarAkun).setVisible(true);
        this.setVisible(false);

        // TODO add your handling code here:
    }//GEN-LAST:event_btn_adminActionPerformed

    private void btn_userActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_userActionPerformed

        new Login(2,DaftarBuku,DaftarAkun).setVisible(true);
        this.setVisible(false);
        //                new form2().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_btn_userActionPerformed

    private void btn_regisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_regisActionPerformed
      new Register(DaftarBuku,DaftarAkun).setVisible(true);
//        this.setVisible(false);
    // TODO add your handling code here:
    }//GEN-LAST:event_btn_regisActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(menu_login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(menu_login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(menu_login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(menu_login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menu_login(DaftarBuku,DaftarAkun).setVisible(true);
                

        baca(DaftarBuku, DaftarAkun);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_admin;
    private javax.swing.JButton btn_regis;
    private javax.swing.JButton btn_user;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    // End of variables declaration//GEN-END:variables
}
