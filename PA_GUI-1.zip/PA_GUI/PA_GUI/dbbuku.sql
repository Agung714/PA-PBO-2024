-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 15, 2024 at 03:38 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbbuku`
--

-- --------------------------------------------------------

--
-- Table structure for table `akun`
--

CREATE TABLE `akun` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `akun`
--

INSERT INTO `akun` (`username`, `password`) VALUES
('a', 'a'),
('b', 'b');

-- --------------------------------------------------------

--
-- Table structure for table `favorit`
--

CREATE TABLE `favorit` (
  `username` varchar(150) NOT NULL,
  `id_buku` int(11) NOT NULL,
  `kategori` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `favorit`
--

INSERT INTO `favorit` (`username`, `id_buku`, `kategori`) VALUES
('a', 1, 'Novel'),
('a', 2, 'Novel'),
('b', 2, 'Novel');

-- --------------------------------------------------------

--
-- Table structure for table `kamus`
--

CREATE TABLE `kamus` (
  `ID` int(11) NOT NULL,
  `Judul` varchar(150) NOT NULL,
  `Penulis` varchar(150) NOT NULL,
  `Harga` int(11) NOT NULL,
  `Stok` int(11) NOT NULL,
  `Bahasa_Awal` varchar(150) NOT NULL,
  `Bahasa_Akhir` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kamus`
--

INSERT INTO `kamus` (`ID`, `Judul`, `Penulis`, `Harga`, `Stok`, `Bahasa_Awal`, `Bahasa_Akhir`) VALUES
(1, '1', '1', 1, 1, '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `novel`
--

CREATE TABLE `novel` (
  `ID` int(11) NOT NULL,
  `Judul` varchar(150) NOT NULL,
  `Harga` double NOT NULL,
  `Penulis` varchar(150) NOT NULL,
  `Stok` int(11) NOT NULL,
  `Genre` varchar(150) NOT NULL,
  `Jumlah_Bab` int(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `novel`
--

INSERT INTO `novel` (`ID`, `Judul`, `Harga`, `Penulis`, `Stok`, `Genre`, `Jumlah_Bab`) VALUES
(1, '1', 1, '1', 1, '1', 1),
(2, '2', 2, '2', 2, '2', 2);

-- --------------------------------------------------------

--
-- Table structure for table `pelajaran`
--

CREATE TABLE `pelajaran` (
  `ID` int(11) NOT NULL,
  `Judul` varchar(150) NOT NULL,
  `Penulis` varchar(150) NOT NULL,
  `Harga` double NOT NULL,
  `Stok` int(11) NOT NULL,
  `Mata_Pelajaran` varchar(150) NOT NULL,
  `Tingkat` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pelajaran`
--

INSERT INTO `pelajaran` (`ID`, `Judul`, `Penulis`, `Harga`, `Stok`, `Mata_Pelajaran`, `Tingkat`) VALUES
(1, '1', '1', 1, 1, '1', '1');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
